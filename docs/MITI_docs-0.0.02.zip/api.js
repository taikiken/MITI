YUI.add("yuidoc-meta", function(Y) {
   Y.YUIDoc = { meta: {
    "classes": [
        "Annai",
        "MITI"
    ],
    "modules": [
        "MITI",
        "inazumatv"
    ],
    "allModules": [
        {
            "displayName": "inazumatv",
            "name": "inazumatv"
        },
        {
            "displayName": "MITI",
            "name": "MITI"
        }
    ]
} };
});